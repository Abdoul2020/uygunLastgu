import React from 'react';
import Linker from "./Linker";


const Navigation = () => (
    <div>
        <Linker />
    </div>)

export default Navigation