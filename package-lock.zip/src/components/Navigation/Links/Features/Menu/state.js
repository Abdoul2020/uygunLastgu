export const items = [{
        categoryName: "Aracım",
        links: [{
                name: "Kasko",
                route: ""
            },
            {
                name: "Trafik Sigortası",
                route: ""
            }
        ]
    },
    {
        categoryName: "Evim",
        links: [{
                name: "Konut Sigortası",
                route: ""
            },
            {
                name: "Evim Güvende",
                route: ""
            },
        ]
    }
]