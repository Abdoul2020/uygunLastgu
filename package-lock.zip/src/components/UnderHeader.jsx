import React from 'react'
import { Link } from 'react-router-dom'

const UnderHeader = () => {
  return (
   
    <div style={{background:"#1c7b17", textAlign:"center", color:"#FFFF"}}>
      <Link to="">
      <small>
      UygunSec sigorta , farklı sigorta şirketler için teklif almanızı sağlar.Bilgi Alın.
      </small>
      </Link>
    
    </div>
  )
}

export default UnderHeader