import { useState,useEffect } from 'react';
import { useSelector } from 'react-redux';

// material-ui
import { useTheme } from '@mui/material/styles';
import {
    Box,
    Button,
    Checkbox,
    Divider,
    FormControl,
    FormControlLabel,
    FormHelperText,
    Grid,
    IconButton,
    InputAdornment,
    InputLabel,
    OutlinedInput,
    Stack,
    Typography,
    useMediaQuery

} from '@mui/material';

// third party
import * as Yup from 'yup';
import { Formik } from 'formik';

// project imports
import useScriptRef from '../hooks/useScriptRef';
import AnimateButton from '../ui-component/extended/AnimateButton';
import { useDispatch } from 'react-redux';
import { useNavigate } from 'react-router-dom';


// assets
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

 //import Google from "../images/logo0.jpeg";

// ============================|| FIREBASE - LOGIN ||============================ //

const FirebaseLogin = ({ ...others }) => {
    const theme = useTheme();
    const scriptedRef = useScriptRef();
    const matchDownSM = useMediaQuery(theme.breakpoints.down('md'));
    // const customization = useSelector((state) => state.customization);
    const [checked, setChecked] = useState(true);

    const googleHandler = async () => {
        console.error('Login');
    };

    const [showPassword, setShowPassword] = useState(false);
    const handleClickShowPassword = () => {
        setShowPassword(!showPassword);
    };

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };



//Send user info to Database
//     console.log('I am in Login');
//   const user = useSelector(selectUser);
//   console.log(user);


//   const navigate = useNavigate();
//   useEffect(() => { if (user.uid) { navigate("/profile"); toastify({ type: 'info', message: 'Lutfen suanki kullanicidan cikis yapiniz.' }); } });

//   const dispatch = useDispatch();


// onSubmit={(e) => { e.preventDefault(); handleSubmit(); handleDataSubmit(e);  }}

//   const handleDataSubmit = (event) => {
//     //event.preventDefault();
//     console.log("dataya girdi");
//     const data = new FormData(event.currentTarget);

//     loginWithEmailAndPassword(data.get('email'), data.get('password')).then(
//       (respUser, verified) => {
//         if (verified === false) {
//           toastify({ type: 'success', message: 'Email Dogrulama linki gonderildi' });
//         }
//         else {
//           let { uid,
//             displayName,
//             email,
//             phoneNumber,
//             emailVerified } = respUser.user;
//           dispatch(updateUser(
//             {
//               uid,
//               displayName,
//               email,
//               phoneNumber,
//               emailVerified
//             })); navigate("/profile");
//         }
//       }

//     )
//       .catch(error => {
//         toastify({ type: 'error', message: error })
//       })
//   };
  
    return (
        <>
            <Grid container direction="column" justifyContent="center" spacing={2}>
                
                
                <Grid item xs={12} container alignItems="center" justifyContent="center">
                    <Box sx={{ mb: 2 }}>
                        <Typography variant="subtitle1">E-posta adresiyle oturum açın.</Typography>
                    </Box>
                </Grid>
            </Grid>

            <Formik

                initialValues={{
                    email: '',
                    password: '',
                    submit: null
                }}
                validationSchema={Yup.object().shape({
                    email: Yup.string().email('Geçerli bir e-posta olmalı').max(255).required('Email gereklidir.'),
                    password: Yup.string().max(255).required('Parola Gereklidir.')
                })}
                onSubmit={async (values, { setErrors, setStatus, setSubmitting }) => {
                    
                    try {
                        if (scriptedRef.current) {
                            setStatus({ success: true });
                            setSubmitting(false);
                        }
                    } catch (err) {
                        console.error(err);
                        if (scriptedRef.current) {
                            setStatus({ success: false });
                            setErrors({ submit: err.message });
                            setSubmitting(false);
                        }
                    }
                }}
            >
                {({ errors, handleBlur, handleChange, handleSubmit, isSubmitting, touched, values }) => (
                    
                    <form noValidate   {...others}>
                        <FormControl fullWidth error={Boolean(touched.email && errors.email)} sx={{ ...theme.typography.customInput }} margin="dense">
                            <InputLabel htmlFor="outlined-adornment-email-login">E - Posta Adresiniz</InputLabel>
                            <OutlinedInput
                                id="outlined-adornment-email-login"
                                type="email"
                                value={values.email}
                                name="email"
                                onBlur={handleBlur}
                                onChange={handleChange}
                                label="E - Posta Adresiniz"
                                inputProps={{}}
                                
                            />
                            {touched.email && errors.email && (
                                <FormHelperText error id="standard-weight-helper-text-email-login">
                                    {errors.email}
                                </FormHelperText>
                            )}
                        </FormControl>

                        <FormControl
                            fullWidth
                            error={Boolean(touched.password && errors.password)}

                            sx={{ ...theme.typography.customInput }}
                            margin="dense"
                        >
                            <InputLabel htmlFor="outlined-adornment-password-login">Parola</InputLabel>
                            <OutlinedInput
                                id="outlined-adornment-password-login"
                                type={showPassword ? 'text' : 'password'}
                                value={values.password}
                                name="password"
                                onBlur={handleBlur}
                                onChange={handleChange}
                                
                                endAdornment={
                                    <InputAdornment position="end">
                                        <IconButton
                                            aria-label="toggle password visibility"
                                            onClick={handleClickShowPassword}
                                            onMouseDown={handleMouseDownPassword}
                                            edge="end"
                                            size="large"
                                        >
                                            {showPassword ? <Visibility /> : <VisibilityOff />}
                                        </IconButton>
                                    </InputAdornment>
                                }
                                label="Parola"
                                inputProps={{}}
                            />
                            {touched.password && errors.password && (
                                <FormHelperText error id="standard-weight-helper-text-password-login">
                                    {errors.password}
                                </FormHelperText>
                            )}
                        </FormControl>
                        <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={1}>
                            <FormControlLabel
                                control={
                                    <Checkbox
                                        checked={checked}
                                        onChange={(event) => setChecked(event.target.checked)}
                                        name="checked"
                                        color="primary"
                                    />
                                }
                                label="Beni Hatırla"
                            />
                            <Typography variant="subtitle1" color="#388ab3" sx={{ textDecoration: 'none', cursor: 'pointer' }}>
                                Şifremi Unuttum?
                            </Typography>
                        </Stack>
                        {errors.submit && (
                            <Box sx={{ mt: 3 }}>
                                <FormHelperText error>{errors.submit}</FormHelperText>
                            </Box>
                        )}

                        <Box sx={{ mt: 2 }}>
                            <AnimateButton>
                                <Button
                                    disableElevation
                                    disabled={isSubmitting}
                                    fullWidth
                                    size="large"
                                    type="submit"
                                    variant="contained"
                                    color="success"
                                >
                                    Üye Girişi
                                </Button>
                            </AnimateButton>
                        </Box>
                    </form>
                )}
            </Formik>
        </>
    );
};

export default FirebaseLogin;
